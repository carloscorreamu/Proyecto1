import sqlite3

def conectar():
    conn = sqlite3.connect("chicas_magicas.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chicas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            edad INTEGER,
            ciudad TEXT,
            estado TEXT CHECK(estado IN ('activa', 'desaparecida', 'rescatada')),
            fecha_contrato TEXT
        )
    """)
    conn.commit()
    conn.close()

def obtener_conexion():
    return sqlite3.connect("chicas_magicas.db")


if __name__ == "__main__":
    conectar()
    print("Base de datos creada correctamente.")
