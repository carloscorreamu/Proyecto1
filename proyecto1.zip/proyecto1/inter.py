import tkinter as tk
from tkinter import ttk, messagebox
import chinche

def actualizar_lista():
    for row in tabla.get_children():
        tabla.delete(row)
    chicas = chinche.listar_chicas()
    for chica in chicas:
        tabla.insert("", "end", values=chica)

def agregar():
    nombre = entry_nombre.get()
    edad = entry_edad.get()
    ciudad = entry_ciudad.get()
    estado = combo_estado.get()
    fecha = entry_fecha.get()

    if nombre and edad and ciudad and estado and fecha:
        chinche.agregar_chica(nombre, int(edad), ciudad, estado, fecha)
        actualizar_lista()
        limpiar_campos()
    else:
        messagebox.showwarning("Advertencia", "Todos los campos son obligatorios")

def eliminar():
    seleccion = tabla.selection()
    if seleccion:
        id_chica = tabla.item(seleccion[0])["values"][0]
        chinche.eliminar_chica(id_chica)
        actualizar_lista()
    else:
        messagebox.showwarning("Advertencia", "Selecciona una chica mágica para eliminar")

def limpiar_campos():
    entry_nombre.delete(0, tk.END)
    entry_edad.delete(0, tk.END)
    entry_ciudad.delete(0, tk.END)
    entry_fecha.delete(0, tk.END)

root = tk.Tk()
root.title("Gestión de Chicas Mágicas")

frame = tk.Frame(root)
frame.pack()

tk.Label(frame, text="Nombre:").grid(row=0, column=0)
entry_nombre = tk.Entry(frame)
entry_nombre.grid(row=0, column=1)

tk.Label(frame, text="Edad:").grid(row=1, column=0)
entry_edad = tk.Entry(frame)
entry_edad.grid(row=1, column=1)

tk.Label(frame, text="Ciudad:").grid(row=2, column=0)
entry_ciudad = tk.Entry(frame)
entry_ciudad.grid(row=2, column=1)

tk.Label(frame, text="Estado:").grid(row=3, column=0)
combo_estado = ttk.Combobox(frame, values=["activa", "desaparecida", "rescatada"])
combo_estado.grid(row=3, column=1)

tk.Label(frame, text="Fecha de contrato:").grid(row=4, column=0)
entry_fecha = tk.Entry(frame)
entry_fecha.grid(row=4, column=1)

btn_agregar = tk.Button(frame, text="Agregar", command=agregar)
btn_agregar.grid(row=5, columnspan=2)

tabla = ttk.Treeview(root, columns=("ID", "Nombre", "Edad", "Ciudad", "Estado", "Fecha de Contrato"), show="headings")
tabla.heading("ID", text="ID")
tabla.heading("Nombre", text="Nombre")
tabla.heading("Edad", text="Edad")
tabla.heading("Ciudad", text="Ciudad")
tabla.heading("Estado", text="Estado")
tabla.heading("Fecha de Contrato", text="Fecha de Contrato")
tabla.pack()

btn_eliminar = tk.Button(root, text="Eliminar", command=eliminar)
btn_eliminar.pack()

actualizar_lista()

root.mainloop()
