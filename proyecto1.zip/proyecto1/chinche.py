
from database import obtener_conexion

def agregar_chica(nombre, edad, ciudad, estado, fecha_contrato):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("INSERT INTO chicas (nombre, edad, ciudad, estado, fecha_contrato) VALUES (?, ?, ?, ?, ?)",
                   (nombre, edad, ciudad, estado, fecha_contrato))
    conexion.commit()
    conexion.close()

def listar_chicas():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM chicas")
    chicas = cursor.fetchall()
    conexion.close()
    return chicas

def actualizar_chica(id_chica, nuevo_estado):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("UPDATE chicas SET estado = ? WHERE id = ?", (nuevo_estado, id_chica))
    conexion.commit()
    conexion.close()

def eliminar_chica(id_chica):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM chicas WHERE id = ?", (id_chica,))
    conexion.commit()
    conexion.close()
