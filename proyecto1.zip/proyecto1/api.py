from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)


def obtener_conexion():
    return sqlite3.connect("chicas_magicas.db")


@app.route("/")
def home():
    return jsonify({"mensaje": "Bienvenido a la API de chicas mágicas"}), 200


@app.route("/chicas", methods=["GET"])
def listar_chicas():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM chicas")
    chicas = cursor.fetchall()
    conexion.close()

    # Convertir datos a formato JSON
    chicas_json = [
        {"id": c[0], "nombre": c[1], "edad": c[2], "ciudad": c[3], "estado": c[4], "fecha_contrato": c[5]}
        for c in chicas
    ]
    return jsonify(chicas_json)


@app.route("/chicas", methods=["POST"])
def agregar_chica():
    datos = request.json  # Recibe los datos en formato JSON
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    
    cursor.execute("INSERT INTO chicas (nombre, edad, ciudad, estado, fecha_contrato) VALUES (?, ?, ?, ?, ?)",
                   (datos["nombre"], datos["edad"], datos["ciudad"], datos["estado"], datos["fecha_contrato"]))
    
    conexion.commit()
    conexion.close()
    
    return jsonify({"mensaje": "Chica mágica agregada correctamente"}), 201


@app.route("/chicas/<int:id_chica>", methods=["DELETE"])
def eliminar_chica(id_chica):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    
    cursor.execute("DELETE FROM chicas WHERE id = ?", (id_chica,))
    
    conexion.commit()
    conexion.close()
    
    return jsonify({"mensaje": f"Chica mágica con ID {id_chica} eliminada"}), 200


@app.route("/chicas/<int:id_chica>", methods=["PUT"])
def actualizar_chica(id_chica):
    datos = request.json
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    
    cursor.execute("UPDATE chicas SET estado = ? WHERE id = ?", (datos["estado"], id_chica))
    
    conexion.commit()
    conexion.close()
    
    return jsonify({"mensaje": f"Estado de la chica mágica con ID {id_chica} actualizado a {datos['estado']}"}), 200


if __name__ == "__main__":
    app.run(debug=True)
